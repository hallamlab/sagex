
To create this figure the following two scripts were run.
First, createKmers.sh 
Second, createPlots.R 

