
# libraries 
library(rgl) 
library(graphics) 

# load data ... 
ecoliSag = read.table("ecoliSag.kmer")
ecoliGen = read.table("ecoliGen.kmer")
nitmaSag = read.table("nitmaSAG.kmer")
pelagSag = read.table("pelagSAG.kmer")

# extract genomes 
metag = ecoliSag[ ecoliSag[,4] != 2 , 1:3 ] ; n1 = nrow(metag)  
ecoliSag = ecoliSag[ ecoliSag[,4] == 2 , 1:3 ] ; n2 = nrow(ecoliSag) 
ecoliGen = ecoliGen[ ecoliGen[,4] == 2 , 1:3 ] ; n3 = nrow(ecoliGen) 
nitmaSag = nitmaSag[ nitmaSag[,4] == 2 , 1:3 ] ; n4 = nrow(nitmaSag) 
pelagSag = pelagSag[ pelagSag[,4] == 2 , 1:3 ] ; n5 = nrow(pelagSag) 

# bind data  
data = rbind( metag , ecoliSag , ecoliGen , nitmaSag , pelagSag ) 

clr = c( "black" , "grey" , "red" , "blue" , "green" )  
clr = c( rep(clr[1],n1) , rep(clr[2],n2) , rep(clr[3],n3) , rep(clr[4],n4) , rep(clr[5],n5) ) 

plot3d( data , col=clr ) 

