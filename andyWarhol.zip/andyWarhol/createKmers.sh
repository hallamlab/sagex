
./sagex -i ecoliSag.fasta -G 4096452_combined_unique.fasta -C 20 -k 2 -P -c -1 -v -X ./ecoliSag.kmer > tmp 
./sagex -i mg1655eColiSubset.fasta -G 4096452_combined_unique.fasta -C 20 -k 2 -P -c -1 -v -X ./ecoliGen.kmer > tmp 
./sagex -i pelagibacterSAG.fasta -G 4096452_combined_unique.fasta -C 20 -k 2 -P -c -1 -v -X ./pelagSAG.kmer > tmp 
./sagex -i nitmaArtificialSAG.fasta -G 4096452_combined_unique.fasta -C 20 -k 2 -P -c -1 -v -X ./nitmaSAG.kmer > tmp

